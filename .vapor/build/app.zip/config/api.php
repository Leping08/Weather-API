<?php

return [

    /*
    |--------------------------------------------------------------------------
    | API Key
    |--------------------------------------------------------------------------
    |
    | This is required to make api calls. Without it the system will
    | respond with unauthenticated
    |
    */

    'key' => env('API_KEY', '123'),

];
